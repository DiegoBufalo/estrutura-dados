import java.util.Arrays;

import javax.swing.JOptionPane;

public class App {
  public static void main(String[] args) {
    int[] vetBubble = solicitarVetor();
    bubbleSort(vetBubble);
    exibirVetor(vetBubble);

    int[] vetSelection = solicitarVetor();
    bubbleSort(vetSelection);
    exibirVetor(vetSelection);

    int[] vetInsertion = solicitarVetor();
    bubbleSort(vetInsertion);
    exibirVetor(vetInsertion);

    int[] vetQuick = solicitarVetor();
    bubbleSort(vetQuick);
    exibirVetor(vetQuick);
  }

  // 60) Elaborar um programa, em linguagem Java, capaz de receber, via teclado e em ordem
  // aleatória, o conteúdo de cada um dos elementos de um vetor do tipo int, de tamanho
  // variável, também digitado, executar a ordenação crescente do mesmo e apresentar o vetor
  // ordenado em tela. Utilizar um método de ordenação por trocas.
  public static void bubbleSort(int[] vet) {
    int iA, iB, iT;
    for (iA = 1; iA <vet.length; iA++) {
        for (iB = vet.length-1; iB >= iA; iB--) {
            if (vet[iB -1] > vet[iB]) {
                iT = vet[iB - 1];
                vet[iB-1] = vet[iB];
                vet[iB] = iT; 
            }
        }
    }
  }


  // 66) Elaborar um programa, em linguagem Java, capaz de receber, em ordem aleatória, o
  // conteúdo de cada elemento de um vetor do tipo double, de tamanho 20, via teclado,
  // executar uma ordenação decrescente do mesmo e apresentar o vetor ordenado em tela.
  // Utilizar um método de ordenação por seleção.
  public static void selectionSort(int[] vet) {
    int iA, iB, iC, iT;
    for (iA = 0; iA <vet.length - 1; iA++) {
        iC = iA;
        iT = vet[iA];
        for (iB = iA + 1; iB < vet.length; iB++) {
            if (vet[iB] < iT) {
                iC = iB;
                iT = vet[iB];
            }
        }
        vet[iC] = vet[iA];
        vet[iA] = iT;
    }
  }


  // 69) Elaborar um programa, em linguagem Java, capaz de receber, em ordem aleatória, o
  // conteúdo de cada elemento de um vetor do tipo char, de tamanho 5, via teclado, executar
  // uma ordenação crescente do mesmo e apresentar o vetor ordenado em tela. Utilizar um
  // método de ordenação por inserção.
  public static void insertionSort(int [] vet) {
    int iA, iB, iT;
    for (iA = 1; iA <vet.length; iA++) {
        iT = vet[iA];
        iB = iA-1;
        while(iB >= 0 && iT < vet[iB]) {
            vet[iB + 1] = vet[iB];
            iB--;
        }
        vet[iB + 1] = iT;
    }
  }


  // 75) Elaborar um programa, em linguagem Java, capaz de receber, via teclado e em ordem
  // aleatória, o conteúdo de cada um dos elementos de um vetor do tipo int, de tamanho
  // variável, também digitado, executar a ordenação crescente do mesmo e apresentar o vetor
  // ordenado em tela. Utilizar um método de ordenação Quick-Sort.
  public static void quickSort(int arr[], int low, int high) {
        if (low < high) {
            int pivot = arr[high];
            int i = (low-1); 
            
            for (int j=low; j<high; j++) {
                if (arr[j] <= pivot){
                    i++;

                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
        }

            int temp = arr[i+1];
            arr[i+1] = arr[high];
            arr[high] = temp;
        
            i++;

      quickSort(arr, low, i-1);
      quickSort(arr, i+1, high);
    }
  }

  public static int[] solicitarVetor() {
    int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Por favor digite o tamanho do vetor desejado."));

    int[] vet = new int[tamanho];
    for (int i=0; i < tamanho; i++) {
      vet[i] = Integer.parseInt(JOptionPane.showInputDialog("Por favor digite o tamanho do vetor desejado."));
    }

    return vet;
  }

  public static void exibirVetor(int[] vet) {
    JOptionPane.showMessageDialog(null, Arrays.toString(vet));
  }
}